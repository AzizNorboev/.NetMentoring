﻿namespace Task1.DoNotChange
{
	public class Supplier
	{
		public string SupplierName { get; set; }
		public string Address { get; set; }
		public string City { get; set; }
		public string Country { get; set; }
	}
}
