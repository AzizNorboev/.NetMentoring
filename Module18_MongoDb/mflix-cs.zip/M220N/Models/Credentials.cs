﻿namespace M220N.Models
{
    public class Credentials
    {
        private string Password { get; set; }

        private string Email { get; set; }
    }
}
