﻿using Listener;

//make sure to comment other 3 tasks when using one

//Task1_URL.NameParserListener(new[] { "http://localhost:8888/" });
//Task2_HttpStatusMessages.StatusCodeListener(new[] { "http://localhost:8888/" });
//Task3_Header.GetName(new[] { "http://localhost:8888/" });
Task4_Cookies.GetNameByCookies(new[] { "http://localhost:8888/" });

