﻿using Client;

//make sure to comment other 3 tasks when using one

//Task1_URL.GetMyName();
//await Task2_HttpStatusMessages.GetStatusMessages();
//await Task3_Header.GetHeaderAsync();
await Task4_Cookies.GetCookiesAsync();