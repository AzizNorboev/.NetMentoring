var action = "I can eat bananas all day";
var sliceResult = action.slice(10,16);

console.log(sliceResult);