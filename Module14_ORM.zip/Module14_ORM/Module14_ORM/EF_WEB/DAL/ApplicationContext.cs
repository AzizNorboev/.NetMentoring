﻿using Microsoft.EntityFrameworkCore;

namespace EF_WEB.DAL
{
    public class ApplicationContext : DbContext
    {
    }
}
