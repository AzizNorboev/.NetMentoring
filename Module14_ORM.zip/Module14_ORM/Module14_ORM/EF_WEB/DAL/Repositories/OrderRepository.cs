﻿namespace EF_WEB.DAL.Repositories
{
    public class OrderRepository : IOrderRepository
    {
    }
}
