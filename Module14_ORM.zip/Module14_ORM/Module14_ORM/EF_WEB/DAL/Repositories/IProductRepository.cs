﻿namespace EF_WEB.DAL.Repositories
{
    public interface IProductRepository
    {
    }
}
