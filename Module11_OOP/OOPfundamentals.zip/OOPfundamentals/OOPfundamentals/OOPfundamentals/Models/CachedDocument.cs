﻿namespace OOPfundamentals.Models
{
    public class CachedDocument
    {
        public string Key { get; set; }
    }
}
