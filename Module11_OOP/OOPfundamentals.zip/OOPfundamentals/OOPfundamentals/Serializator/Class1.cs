﻿using System;

namespace Serializator
{
    public class Class1
    {
    }
}
